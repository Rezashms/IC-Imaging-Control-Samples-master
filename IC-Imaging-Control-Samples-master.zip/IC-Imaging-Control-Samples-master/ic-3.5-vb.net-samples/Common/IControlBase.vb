
Friend Interface IControlBase

    Sub UpdateControl()

End Interface

Friend Interface IControlSlider

    Sub ScrollUpdate()

End Interface
