# IC Imaging Control in a WDF Project

This C# sample shows how to use IC Imaging Control 3.5 in a WPF project. The live video is rendered in a WPF user control.
