﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibPolarizationCamera
{
    public static class VCDGUIDs
    {
        public static Guid VCDID_PolarizationVisualizationMode = new Guid("15DD5A42-673C-468D-B1B8-059C114191DB");
    }
}
