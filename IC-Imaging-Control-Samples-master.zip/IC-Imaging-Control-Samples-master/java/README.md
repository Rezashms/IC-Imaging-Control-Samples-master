# Java
This subdirectory is a test for JAVA and IC Imaging Control

Running example
Step 1 compile:
javac -classpath ic.jar;. test1.java
Step 2 run:
java -classpath ic.jar;. test1.java
