# Python samples for Windows

The "tisgrabber" contains a new approach for using the tisgrabber.dll with ctypes module.
There is also a preliminary tutorial in the "documentation" directory.

Please use this approach. Instead of git cloning you can download the "tisgrabber.zip" file, it contains all necessary files.
