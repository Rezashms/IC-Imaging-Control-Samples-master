.. Python tisgrabber Tutorial documentation master file, created by
   sphinx-quickstart on Fri Oct  8 11:52:22 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python tisgrabber 
======================================================
Overview
--------

.. toctree::
   :maxdepth: 4
   
   tutorial.rst 


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. index::
   