The "documentation" directory contains a tutorial. Start with "index.html"
